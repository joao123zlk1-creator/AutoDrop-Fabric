package br.autodrop;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.ClickType;

public final class AutoDropController {
    private enum Stage { WAITING, COMMAND_SENT, DROPPING }
    private static Stage stage = Stage.WAITING;
    private static long ticks = 0;
    private static int slotCursor = 0;

    private AutoDropController() {}

    public static void reset() {
        ticks = 0;
        slotCursor = 0;
        stage = Stage.WAITING;
    }

    // Chamado uma vez por tick pelo mixin do cliente.
    public static void tick(Minecraft client) {
        if (!AutoDropClient.enabled() || client.player == null || client.level == null) {
            return;
        }

        ticks++;

        if (stage == Stage.WAITING) {
            long intervalTicks = AutoDropClient.intervalSeconds() * 20L;
            if (ticks >= intervalTicks) {
                String command = AutoDropClient.command();
                if (!command.isBlank()) {
                    client.player.connection.sendCommand(command);
                    stage = Stage.COMMAND_SENT;
                    ticks = 0;
                }
            }
            return;
        }

        // Dá 2 segundos para o servidor processar o comando antes de abrir o inventário.
        if (stage == Stage.COMMAND_SENT && ticks >= 40) {
            client.setScreen(new InventoryScreen(client.player));
            stage = Stage.DROPPING;
            ticks = 0;
            slotCursor = 0;
            return;
        }

        if (stage == Stage.DROPPING && ticks >= 2) {
            ticks = 0;
            var player = client.player;
            var menu = player.inventoryMenu;

            // Menu do inventário: 5-8 armadura, 9-35 inventário,
            // 36-44 hotbar e 45 mão secundária. Ignora crafting 0-4.
            int[] inventorySlots = {
                5, 6, 7, 8,
                9, 10, 11, 12, 13, 14, 15, 16, 17,
                18, 19, 20, 21, 22, 23, 24, 25, 26,
                27, 28, 29, 30, 31, 32, 33, 34, 35,
                36, 37, 38, 39, 40, 41, 42, 43, 44,
                45
            };

            if (slotCursor >= inventorySlots.length) {
                client.setScreen(null);
                stage = Stage.WAITING;
                ticks = 0;
                return;
            }

            int slot = inventorySlots[slotCursor++];
            if (client.gameMode != null && slot < menu.slots.size()
                    && menu.getSlot(slot).hasItem()) {
                // THROW com botão 1 descarta a pilha inteira daquele slot.
                client.gameMode.handleInventoryMouseClick(
                    menu.containerId, slot, 1, ClickType.THROW, player
                );
            }
        }
    }
}
