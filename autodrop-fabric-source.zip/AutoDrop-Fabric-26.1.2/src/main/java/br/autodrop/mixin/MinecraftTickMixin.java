package br.autodrop.mixin;

import br.autodrop.AutoDropController;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftTickMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void autodrop$onTick(CallbackInfo ci) {
        AutoDropController.tick((Minecraft) (Object) this);
    }
}
