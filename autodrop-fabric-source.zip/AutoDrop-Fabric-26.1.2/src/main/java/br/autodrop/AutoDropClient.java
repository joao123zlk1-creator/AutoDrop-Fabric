package br.autodrop;

import net.fabricmc.api.ClientModInitializer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class AutoDropClient implements ClientModInitializer {
    public static final Properties CONFIG = new Properties();
    public static Path CONFIG_PATH;

    @Override
    public void onInitializeClient() {
        CONFIG_PATH = Path.of("config", "autodrop.properties");
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            if (Files.notExists(CONFIG_PATH)) {
                CONFIG.setProperty("command", "ec");
                CONFIG.setProperty("intervalSeconds", "1800");
                CONFIG.setProperty("enabled", "false");
                saveConfig();
            } else {
                try (var in = Files.newInputStream(CONFIG_PATH)) {
                    CONFIG.load(in);
                }
            }
        } catch (IOException e) {
            System.err.println("[AutoDrop] Não foi possível carregar a configuração: " + e.getMessage());
        }
        AutoDropController.reset();
        System.out.println("[AutoDrop] Configuração carregada. Edite config/autodrop.properties.");
    }

    public static String command() {
        return CONFIG.getProperty("command", "ec").trim().replaceFirst("^/", "");
    }

    // Aceita de 10 segundos a 10 horas (36.000 segundos).
    public static int intervalSeconds() {
        try {
            int value = Integer.parseInt(CONFIG.getProperty("intervalSeconds", "1800").trim());
            return Math.max(10, Math.min(36_000, value));
        } catch (NumberFormatException e) {
            return 1_800;
        }
    }

    public static boolean enabled() {
        return Boolean.parseBoolean(CONFIG.getProperty("enabled", "false"));
    }

    public static void saveConfig() throws IOException {
        try (var out = Files.newOutputStream(CONFIG_PATH)) {
            CONFIG.store(out, "Auto Drop - command and interval");
        }
    }
}
