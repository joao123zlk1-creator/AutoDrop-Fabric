@echo off
echo Auto Drop - build para Minecraft 26.1.2
echo.
echo Requer JDK 25 e Gradle 9.4.0 instalado.
echo Este pacote ainda nao inclui o Gradle Wrapper.
echo.
gradle --version
if errorlevel 1 (
  echo Gradle nao encontrado no PATH.
  pause
  exit /b 1
)
gradle build
pause
