# Auto Drop Fabric — Minecraft 26.1.2

## Estado deste pacote
Este é um **projeto-fonte**, não um `.jar` pronto. Não foi possível compilar nem testar nesta sessão: o ambiente só tem Java 21 e não consegue acessar a internet para baixar JDK 25, Gradle, Loom ou as bibliotecas do Minecraft. Não use o ZIP como se fosse um mod instalável.

## Funções planejadas no código
- Comando configurável no arquivo `config/autodrop.properties` (ex.: `ec`, sem a barra).
- Contador configurável de **10 segundos a 10 horas**.
- Quando o contador termina: envia o comando, espera 2 segundos, abre o inventário e descarta as pilhas slot por slot.
- O descarte usa a ação THROW de pilha inteira para cada slot ocupado.
- O mod inicia desativado (`enabled=false`) para evitar descarte acidental.

## Configuração
Depois de uma primeira inicialização bem-sucedida, edite `config/autodrop.properties`:
- `command=ec` — escreva o comando sem `/`.
- `intervalSeconds=1800` — segundos. Exemplos: `10`, `30`, `600`, `1800`, `3600`, `36000`.
- `enabled=false` — altere para `true` somente quando quiser ativar.

Valores fora do intervalo são limitados a 10–36.000 segundos.

## Requisitos de desenvolvimento para 26.1.x
A documentação Fabric para 26.1 indica Java 25+, Loom 1.15 e Gradle 9.4.0; 26.1 usa nomes oficiais e o plugin `net.fabricmc.fabric-loom`, sem remapeamento antigo. Consulte:
- https://fabricmc.net/2026/03/14/261.html
- https://docs.fabricmc.net/versions/26.1.2/develop/

## Limitações importantes
- A interface de configuração nesta versão é o arquivo `.properties`, não uma tela dentro do jogo.
- O servidor pode rejeitar/limitar ações automatizadas ou a execução do comando.
- O código ainda precisa ser compilado e testado contra as APIs exatas de 26.1.2. O nome de classes/métodos do inventário pode exigir ajustes após a primeira compilação.
- Faça primeiro um teste em mundo separado, com inventário sem itens importantes. O descarte é irreversível dentro do jogo.
